from django.shortcuts import render
from apps.services.models import Service, ServiceCategory
from apps.gallery.models import GalleryItem
from apps.bookings.models import BusinessHours

def home_view(request):
    featured_services = Service.objects.filter(is_active=True, is_featured=True).select_related('category')[:4]
    if not featured_services:
        featured_services = Service.objects.filter(is_active=True).select_related('category')[:4]

    category_lookup = {
        category.audience: category
        for category in ServiceCategory.objects.filter(is_active=True, audience__in=['men', 'women']).order_by('display_order', 'name')
    }
    category_cards = [
        {
            'audience': 'men',
            'title': category_lookup.get('men').name if category_lookup.get('men') else 'Hommes',
            'description': category_lookup.get('men').description if category_lookup.get('men') else 'Coupes, dégradés, barbe et plus',
            'url_name': 'services:men',
        },
        {
            'audience': 'women',
            'title': category_lookup.get('women').name if category_lookup.get('women') else 'Femmes',
            'description': category_lookup.get('women').description if category_lookup.get('women') else 'Coupes, brushing, coloration et plus',
            'url_name': 'services:women',
        },
    ]

    recent_gallery = GalleryItem.objects.filter(is_published=True).select_related('related_service')[:6]
    business_hours = BusinessHours.objects.all().order_by('weekday')

    context = {
        'category_cards': category_cards,
        'featured_services': featured_services,
        'recent_gallery': recent_gallery,
        'business_hours': business_hours,
        'meta_title': "Chelsea Coiffure - Coiffeuse Privée & Réservation en Ligne",
        'meta_description': "Découvrez les prestations de Chelsea : coupes hommes et femmes, soins sur mesure. Réservez votre créneau directement en ligne !",
    }
    return render(request, 'core/home.html', context)

def privacy_policy_view(request):
    return render(request, 'core/privacy_policy.html', {'meta_title': "Politique de Confidentialité - Chelsea Coiffure"})

def cancellation_policy_view(request):
    return render(request, 'core/cancellation_policy.html', {'meta_title': "Politique d'Annulation - Chelsea Coiffure"})

def terms_view(request):
    return render(request, 'core/terms.html', {'meta_title': "Conditions Générales - Chelsea Coiffure"})

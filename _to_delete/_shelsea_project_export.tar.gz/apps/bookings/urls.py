from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('', views.booking_wizard_view, name='wizard'),
    path('disponibilites/', views.availability_api_view, name='disponibilites'),
    path('confirmation/<uuid:public_id>/', views.booking_confirmation_view, name='confirmation'),
    path('annuler/<uuid:public_id>/<str:token>/', views.cancel_appointment_view, name='cancel'),
]

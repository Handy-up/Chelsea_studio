from datetime import datetime, timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.conf import settings
from django.utils import timezone
from django.utils.crypto import get_random_string
from apps.services.models import Service
from apps.bookings.models import Appointment
from apps.bookings.forms import BookingCustomerForm
from apps.bookings.services.availability import AvailabilityService, SlotUnavailableError
from apps.core.rate_limit import is_rate_limited
from apps.notifications.services.email_service import EmailService

BOOKING_NONCE_SESSION_KEY = 'booking_nonce'


def get_or_create_booking_nonce(request):
    nonce = request.session.get(BOOKING_NONCE_SESSION_KEY)
    if not nonce:
        nonce = get_random_string(32)
        request.session[BOOKING_NONCE_SESSION_KEY] = nonce
    return nonce


def booking_wizard_view(request):
    """
    Vue principale du tunnel de réservation étape par étape.
    """
    selected_service_id = request.GET.get('service') or request.POST.get('service_id')
    selected_date_str = request.GET.get('date') or request.POST.get('date')
    selected_slot = request.GET.get('slot') or request.POST.get('slot')

    services = Service.objects.filter(is_active=True).select_related('category')
    selected_service = None
    if selected_service_id:
        selected_service = services.filter(pk=selected_service_id).first()

    today = timezone.now().date()
    # Générer les 14 prochains jours pour le sélecteur de dates rapide
    available_dates = [today + timedelta(days=i) for i in range(14)]

    available_slots = []
    if selected_service and selected_date_str:
        try:
            available_slots = AvailabilityService.get_available_slots(selected_service, selected_date_str)
        except Exception:
            available_slots = []

    form = BookingCustomerForm(request.POST or None)
    booking_nonce = get_or_create_booking_nonce(request)

    if request.method == 'POST' and request.POST.get('action') == 'submit_booking':
        posted_nonce = request.POST.get('booking_nonce', '')
        if is_rate_limited(request, 'booking', getattr(settings, 'BOOKING_RATE_LIMIT_PER_HOUR', 8)):
            messages.error(request, "Trop de demandes de réservation ont été envoyées depuis cet appareil. Merci de réessayer plus tard.")
        elif not posted_nonce or posted_nonce != request.session.get(BOOKING_NONCE_SESSION_KEY):
            messages.error(request, "Ce formulaire a déjà été envoyé ou a expiré. Merci de réessayer.")
            request.session[BOOKING_NONCE_SESSION_KEY] = get_random_string(32)
            booking_nonce = request.session[BOOKING_NONCE_SESSION_KEY]
        elif not selected_service:
            messages.error(request, "Veuillez sélectionner un service.")
        elif not selected_slot:
            messages.error(request, "Veuillez choisir un créneau horaire.")
        elif form.is_valid():
            try:
                # Appeler le moteur de réservation transactionnel
                appointment = AvailabilityService.book_appointment(
                    customer_data=form.cleaned_data,
                    service=selected_service,
                    starts_at_dt=selected_slot,
                    client_note=form.cleaned_data.get('client_note', '')
                )

                # Envoyer les notifications par email
                EmailService.send_notification(appointment, 'confirmation_request')
                EmailService.send_notification(appointment, 'new_appointment_admin')

                request.session.pop(BOOKING_NONCE_SESSION_KEY, None)
                return redirect('bookings:confirmation', public_id=appointment.public_id)

            except SlotUnavailableError as err:
                messages.error(request, str(err))
            except Exception as e:
                messages.error(request, f"Une erreur est survenue lors de la réservation : {e}")

    context = {
        'services': services,
        'selected_service': selected_service,
        'selected_date_str': selected_date_str,
        'selected_slot': selected_slot,
        'available_dates': available_dates,
        'available_slots': available_slots,
        'form': form,
        'booking_nonce': booking_nonce,
        'meta_title': "Prendre Rendez-vous - Chelsea Coiffure",
        'meta_description': "Réservez votre créneau coiffure avec Chelsea en quelques clics.",
    }
    return render(request, 'bookings/booking_wizard.html', context)


def availability_api_view(request):
    """
    Endpoint HTMX pour mettre à jour la liste des créneaux en fonction de la date et du service.
    """
    service_id = request.GET.get('service_id')
    date_str = request.GET.get('date')

    if not service_id or not date_str:
        return render(request, 'bookings/partials/slots_list.html', {'slots': [], 'error': "Paramètres manquants"})

    service = Service.objects.filter(pk=service_id, is_active=True).first()
    if not service:
        return render(request, 'bookings/partials/slots_list.html', {'slots': [], 'error': "Service introuvable"})

    try:
        slots = AvailabilityService.get_available_slots(service, date_str)
    except Exception as e:
        slots = []

    context = {
        'slots': slots,
        'service': service,
        'date_str': date_str,
    }
    return render(request, 'bookings/partials/slots_list.html', context)


def booking_confirmation_view(request, public_id):
    appointment = get_object_or_404(
        Appointment.objects.select_related('customer', 'service'),
        public_id=public_id
    )
    context = {
        'appointment': appointment,
        'meta_title': "Confirmation de Réservation - Chelsea Coiffure",
    }
    return render(request, 'bookings/confirmation.html', context)


def cancel_appointment_view(request, public_id, token):
    appointment = get_object_or_404(Appointment, public_id=public_id, confirmation_token=token)

    if request.method == 'POST':
        if appointment.status in ['cancelled_by_customer', 'cancelled_by_admin']:
            messages.info(request, "Ce rendez-vous a déjà été annulé.")
        else:
            appointment.status = 'cancelled_by_customer'
            appointment.save()
            EmailService.send_notification(appointment, 'cancelled')
            messages.success(request, "Votre rendez-vous a été annulé avec succès.")
            return redirect('core:home')

    return render(request, 'bookings/cancel.html', {'appointment': appointment})
